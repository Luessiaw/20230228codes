

class Trans:

    def __init__(self,id,T1='',T2='',T3='00000000',T4='000000000000',T5='0000',T6='',T7='01',T8='1',T9='000000',T10='',
                 T11='0',T12='0000000000',T13='',T14='',T15='',T16='0',T17='',T18='01',T19='',T20='00000000',
                 T21='0',T22='',T23='',T24='00000000',T25='',T26='',T27='00',T28='',T29='00000000',T30='',
                 T31='00000000',T32='',T33='',T34='',T35='01',T36='',T37='',T38='1', T39='1',
                 abnormal=0, abnormal_state= {"赌博违规交易": 0, "伪冒注册欺诈": 0,"信用卡违规套现":0, "黄牛营销欺诈":0, "商户违规":0,"异常转账":0}):
        self.id = id
        self.T1 = T1
        self.T2 = T2
        self.T3 = T3
        self.T4 = T4
        self.T5 = T5
        self.T6 = T6
        self.T7 = T7
        self.T8 = T8
        self.T9 = T9
        self.T10 = T10
        self.T11 = T11
        self.T12 = T12
        self.T13 = T13
        self.T14 = T14
        self.T15 = T15
        self.T16 = T16
        self.T17 = T17
        self.T18 = T18
        self.T19 = T19
        self.T20 = T20
        self.T21 = T21
        self.T22 = T22
        self.T23 = T23
        self.T24 = T24
        self.T25 = T25
        self.T26 = T26
        self.T27 = T27
        self.T28 = T28
        self.T29 = T29
        self.T30 = T30
        self.T31 = T31
        self.T32 = T32
        self.T33 = T33
        self.T34 = T34
        self.T35 = T35
        self.T36 = T36
        self.T37 = T37
        self.T38 = T38
        self.T39 = T39
        self.abnormal = abnormal
        self.abnormal_state = abnormal_state

    def set_id(self, id):
        self.id = id

    def get_id(self):
        return self.id

    def set_T1(self, T1):
        self.T1 = T1

    def get_T1(self):
        return self.T1

    def set_T2(self, T2):
        self.T2 = T2

    def get_T2(self):
        return self.T2

    def set_T3(self, T3):
        self.T3 = T3

    def get_T3(self):
        return self.T3

    def set_T4(self, T4):
        self.T4 = T4

    def get_T4(self):
        return self.T4

    def set_T5(self, T5):
        self.T5 = T5

    def get_T5(self):
        return self.T5

    def set_T6(self, T6):
        self.T6 = T6

    def get_T6(self):
        return self.T6

    def set_T7(self, T7):
        self.T7 = T7

    def get_T7(self):
        return self.T7

    def set_T8(self, T8):
        self.T8 = T8

    def get_T8(self):
        return self.T8

    def set_T9(self, T9):
        self.T9 = T9

    def get_T9(self):
        return self.T9

    def set_T10(self, T10):
        self.T10 = T10

    def get_T10(self):
        return self.T10

    def set_T11(self, T11):
        self.T11 = T11

    def get_T11(self):
        return self.T11

    def set_T12(self, T12):
        self.T12 = T12

    def get_T12(self):
        return self.T12

    def set_T13(self, T13):
        self.T13 = T13

    def get_T13(self):
        return self.T13

    def set_T14(self, T14):
        self.T14 = T14

    def get_T14(self):
        return self.T14

    def set_T15(self, T15):
        self.T15 = T15

    def get_T15(self):
        return self.T15

    def set_T16(self, T16):
        self.T16 = T16

    def get_T16(self):
        return self.T16

    def set_T17(self, T17):
        self.T17 = T17

    def get_T17(self):
        return self.T17

    def set_T18(self, T18):
        self.T18 = T18

    def get_T18(self):
        return self.T18

    def set_T19(self, T19):
        self.T19 = T19

    def get_T19(self):
        return self.T19

    def set_T20(self, T20):
        self.T20 = T20

    def get_T20(self):
        return self.T20

    def set_T21(self, T21):
        self.T21 = T21

    def get_T21(self):
        return self.T21

    def set_T22(self, T22):
        self.T22 = T22

    def get_T22(self):
        return self.T22

    def set_T23(self, T23):
        self.T23 = T23

    def get_T23(self):
        return self.T23

    def set_T24(self, T24):
        self.T24 = T24

    def get_T24(self):
        return self.T24

    def set_T25(self, T25):
        self.T25 = T25

    def get_T25(self):
        return self.T25

    def set_T26(self, T26):
        self.T26 = T26

    def get_T26(self):
        return self.T26

    def set_T27(self, T27):
        self.T27 = T27

    def get_T27(self):
        return self.T27

    def set_T28(self, T28):
        self.T28 = T28

    def get_T28(self):
        return self.T28

    def set_T29(self, T29):
        self.T29 = T29

    def get_T29(self):
        return self.T29

    def set_T30(self, T30):
        self.T30 = T30

    def get_T30(self):
        return self.T30

    def set_T31(self, T31):
        self.T31 = T31

    def get_T31(self):
        return self.T31

    def set_T32(self, T32):
        self.T32 = T32

    def get_T32(self):
        return self.T32

    def set_T33(self, T33):
        self.T33 = T33

    def get_T33(self):
        return self.T33

    def set_T34(self, T34):
        self.T34 = T34

    def get_T34(self):
        return self.T34

    def set_T35(self, T35):
        self.T35 = T35

    def get_T35(self):
        return self.T35

    def set_T36(self, T36):
        self.T36 = T36

    def get_T36(self):
        return self.T36

    def set_T37(self, T37):
        self.T37 = T37

    def get_T37(self):
        return self.T37

    def set_T38(self, T38):
        self.T38 = T38

    def get_T38(self):
        return self.T38

    def set_T39(self, T39):
        self.T39 = T39

    def get_T39(self):
        return self.T39

    def set_abnormal(self, abnormal):
        self.abnormal = abnormal

    def get_abnormal(self):
        return self.abnormal

    def set_abnormal_state(self, abnormal_state):
        self.abnormal_state = abnormal_state

    def get_abnormal_state(self):
        return self.abnormal_state

    def get_trans_info(self):
        return {
            "id":self.id,
            "T1": self.T1,
            "T2": self.T2,
            "T3": self.T3,
            "T4": self.T4,
            "T5": self.T5,
            "T6": self.T6,
            "T7": self.T7,
            "T8": self.T8,
            "T9": self.T9,
            "T10": self.T10,
            "T11": self.T11,
            "T12": self.T12,
            "T13": self.T13,
            "T14": self.T14,
            "T15": self.T15,
            "T16": self.T16,
            "T17": self.T17,
            "T18": self.T18,
            "T19": self.T19,
            "T20": self.T20,
            "T21": self.T21,
            "T22": self.T22,
            "T23": self.T23,
            "T24": self.T24,
            "T25": self.T25,
            "T26": self.T26,
            "T27": self.T27,
            "T28": self.T28,
            "T29": self.T29,
            "T30": self.T30,
            "T31": self.T31,
            "T32": self.T32,
            "T33": self.T33,
            "T34": self.T34,
            "T35": self.T35,
            "T36": self.T36,
            "T37": self.T37,
            "T38": self.T38,
            "T39": self.T39,
            "abnormal": self.abnormal,
            "abnormal_state": self.abnormal_state
        }


