# -*- coding:utf-8 -*-
# @Time     :2022/6/24 15:01
# @Author   :Guo Jiayu
from src.dataGen20220414.entity.Trans import Trans


class FraduTrans:

    def __init__(self, id, F1, F2, F3, F4, F5,
                 F6, F7, F8, F9, F10, F11, F12, F13,
                 F14, F15, F16, F17, F18, F19, F20, F21,
                 F22, F23, F24, F25, F26, F27, F28, F29,
                 F30, F31, F32, F33, F34, F35, F36, F37,
                 F38, F39, F40, F41, F42, F43,
                 F44, F45):
        self.id = id
        self.F1 = F1
        self.F2 = F2
        self.F3 = F3
        self.F4 = F4
        self.F5 = F5
        self.F6 = F6
        self.F7 = F7
        self.F8 = F8
        self.F9 = F9
        self.F10 = F10
        self.F11 = F11
        self.F12 = F12
        self.F13 = F13
        self.F14 = F14
        self.F15 = F15
        self.F16 = F16
        self.F17 = F17
        self.F18 = F18
        self.F19 = F19
        self.F20 = F20
        self.F21 = F21
        self.F22 = F22
        self.F23 = F23
        self.F24 = F24
        self.F25 = F25
        self.F26 = F26
        self.F27 = F27
        self.F28 = F28
        self.F29 = F29
        self.F30 = F30
        self.F31 = F31
        self.F32 = F32
        self.F33 = F33
        self.F34 = F34
        self.F35 = F35
        self.F36 = F36
        self.F37 = F37
        self.F38 = F38
        self.F39 = F39
        self.F40 = F40
        self.F41 = F41
        self.F42 = F42
        self.F43 = F43
        self.F44 = F44
        self.F45 = F45


    def get_f_t_info(self):
        return {
            "id": self.id,
            "F1": self.F1,
            "F2": self.F2,
            "F3": self.F3,
            "F4": self.F4,
            "F5": self.F5,
            "F6": self.F6,
            "F7": self.F7,
            "F8": self.F8,
            "F9": self.F9,
            "F10": self.F10,
            "F11": self.F11,
            "F12": self.F12,
            "F13": self.F13,
            "F14": self.F14,
            "F15": self.F15,
            "F16": self.F16,
            "F17": self.F17,
            "F18": self.F18,
            "F19": self.F19,
            "F20": self.F20,
            "F21": self.F21,
            "F22": self.F22,
            "F23": self.F23,
            "F24": self.F24,
            "F25": self.F25,
            "F26": self.F26,
            "F27": self.F27,
            "F28": self.F28,
            "F29": self.F29,
            "F30": self.F30,
            "F31": self.F31,
            "F32": self.F32,
            "F33": self.F33,
            "F34": self.F34,
            "F35": self.F35,
            "F36": self.F36,
            "F37": self.F37,
            "F38": self.F38,
            "F39": self.F39,
            "F40": self.F40,
            "F41": self.F41,
            "F42": self.F42,
            "F43": self.F43,
            "F44": self.F44,
            "F45": self.F45
        }

    def set_id(self, id):
        self.id = id

    def get_id(self):
        return self.id

    def set_F1(self, F1):
        self.F1 = F1

    def get_F1(self):
        return self.F1

    def set_F2(self, F2):
        self.F2 = F2

    def get_F2(self):
        return self.F2

    def set_F3(self, F3):
        self.F3 = F3

    def get_F3(self):
        return self.F3

    def set_F4(self, F4):
        self.F4 = F4

    def get_F4(self):
        return self.F4

    def set_F5(self, F5):
        self.F5 = F5

    def get_F5(self):
        return self.F5

    def set_F6(self, F6):
        self.F6 = F6

    def get_F6(self):
        return self.F6

    def set_F7(self, F7):
        self.F7 = F7

    def get_F7(self):
        return self.F7

    def set_F8(self, F8):
        self.F8 = F8

    def get_F8(self):
        return self.F8

    def set_F9(self, F9):
        self.F9 = F9

    def get_F9(self):
        return self.F9

    def set_F10(self, F10):
        self.F10 = F10

    def get_F10(self):
        return self.F10

    def set_F11(self, F11):
        self.F11 = F11

    def get_F11(self):
        return self.F11

    def set_F12(self, F12):
        self.F12 = F12

    def get_F12(self):
        return self.F12

    def set_F13(self, F13):
        self.F13 = F13

    def get_F13(self):
        return self.F13

    def set_F14(self, F14):
        self.F14 = F14

    def get_F14(self):
        return self.F14

    def set_F15(self, F15):
        self.F15 = F15

    def get_F15(self):
        return self.F15

    def set_F16(self, F16):
        self.F16 = F16

    def get_F16(self):
        return self.F16

    def set_F17(self, F17):
        self.F17 = F17

    def get_F17(self):
        return self.F17

    def set_F18(self, F18):
        self.F18 = F18

    def get_F18(self):
        return self.F18

    def set_F19(self, F19):
        self.F19 = F19

    def get_F19(self):
        return self.F19

    def set_F20(self, F20):
        self.F20 = F20

    def get_F20(self):
        return self.F20

    def set_F21(self, F21):
        self.F21 = F21

    def get_F21(self):
        return self.F21

    def set_F22(self, F22):
        self.F22 = F22

    def get_F22(self):
        return self.F22

    def set_F23(self, F23):
        self.F23 = F23

    def get_F23(self):
        return self.F23

    def set_F24(self, F24):
        self.F24 = F24

    def get_F24(self):
        return self.F24

    def set_F25(self, F25):
        self.F25 = F25

    def get_F25(self):
        return self.F25

    def set_F26(self, F26):
        self.F26 = F26

    def get_F26(self):
        return self.F26

    def set_F27(self, F27):
        self.F27 = F27

    def get_F27(self):
        return self.F27

    def set_F28(self, F28):
        self.F28 = F28

    def get_F28(self):
        return self.F28

    def set_F29(self, F29):
        self.F29 = F29

    def get_F29(self):
        return self.F29

    def set_F30(self, F30):
        self.F30 = F30

    def get_F30(self):
        return self.F30

    def set_F31(self, F31):
        self.F31 = F31

    def get_F31(self):
        return self.F31

    def set_F32(self, F32):
        self.F32 = F32

    def get_F32(self):
        return self.F32

    def set_F33(self, F33):
        self.F33 = F33

    def get_F33(self):
        return self.F33

    def set_F34(self, F34):
        self.F34 = F34

    def get_F34(self):
        return self.F34

    def set_F35(self, F35):
        self.F35 = F35

    def get_F35(self):
        return self.F35

    def set_F36(self, F36):
        self.F36 = F36

    def get_F36(self):
        return self.F36

    def set_F37(self, F37):
        self.F37 = F37

    def get_F37(self):
        return self.F37

    def set_F38(self, F38):
        self.F38 = F38

    def get_F38(self):
        return self.F38

    def set_F39(self, F39):
        self.F39 = F39

    def get_F39(self):
        return self.F39

    def set_F40(self, F40):
        self.F40 = F40

    def get_F40(self):
        return self.F40

    def set_F41(self, F41):
        self.F41 = F41

    def get_F41(self):
        return self.F41

    def set_F42(self, F42):
        self.F42 = F42

    def get_F42(self):
        return self.F42

    def set_F43(self, F43):
        self.F43 = F43

    def get_F43(self):
        return self.F43

    def set_F44(self, F44):
        self.F44 = F44

    def get_F44(self):
        return self.F44

    def set_F45(self, F45):
        self.F45 = F45

    def get_F45(self):
        return self.F45
if __name__ == '__main__':
    # fraduTrans = FraduTrans(None, None, None, None, None, None, None, None, None, None, None, None, None, None, None,
    #                         None, None, None, None, None,
    #                         None, None, None, None, None, None, None, None, None, None, None, None, None, None, None,
    #                         None, None, None, None, None,
    #                         None, None, None, None, None, None)
    fraduTrans = Trans(None)

    # for k in fraduTrans.__dict__:
    #     print("def set_" + k + "(self," + k + "):")
    #     print("\tself." + k + "=" + k)
    #     print("def get_" + k + "(self):")
    #     print("\treturn self." + k)
        # print(k + ",")

    for i in range(1,40):
        # print('"T' + str(i) + '":self.T' + str(i) + ",")
        # print("T" + str(i) + "=trans.T" + str(i))
        print("T" + str(i) + ",", end='')

