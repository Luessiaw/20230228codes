import json
import random
import numpy as np

from src.utils.config import BASE_DIR
from src.utils.functions import read_json_file

def get_consume_type(user, consume_type_times):
    """
    # 通过表3和表1获取
    # 通过表3加权随机，通过表1限制不同消费的次数
    :param user:
    :param consume_type_times:
    :return:
    """
    # 加载年龄消费倾向与年龄消费次数限制的json文件                                                                   
    f1 = open(BASE_DIR +"/src/json_file/consume_age_inclination.json", 'r', encoding="UTF-8")
    consume_age_inclination = json.load(f1)                                                      
    # print(consume_inclination)                                                             
    f2 = open(BASE_DIR +"/src/json_file/consume_age_time_limit", 'r', encoding="UTF-8")
    consume_time_limit = json.load(f2)                                                       
    # print(consume_time_limit)                                                              
    # print('user:', user)                                                                   
    # print('consume_type_times:', consume_type_times)                                       
                                                                                             
    consume_type = ''
    consume_limit = ''   #  新增 消费次数限制 consume_limit
    # 根据消费倾向表中的概率生成每次交易的种类                                                                   
    for key in list(consume_age_inclination.keys()):                                             
        if key == '-':                                                                       
            consume_type = random_key(consume_age_inclination[key])                              
            break                                                                            
        # 根据年龄选择消费倾向概率分布                                                                     
        if user['age'] <= int(key):                                   
            consume_incl = consume_age_inclination[key].copy()                                   
            # 如果某种交易已经达到上限，不再考虑 
			
            for key_limit in list(consume_time_limit.keys()):      # 新增一个for循环，根据年龄消费次数限制表确定消费次数限制 consume_limit
                if key_limit == '-':                                                                       
                    consume_limit = consume_time_limit[key_limit]                          
                    break                                                                            
				# 根据年龄选择消费倾向概率分布                                                                     
                if user['age'] <= int(key_limit):
                    consume_limit = consume_time_limit[key_limit]                              
                    break  
			
            for k in consume_type_times.keys():                                              
                if consume_type_times[k] >= consume_limit[k][1]:                        
                    consume_incl.pop(k)                                                      
            consume_type = random_key(consume_incl)                                          
            break   
    return consume_type

def dir_average(dir1, dir2, w):
    # 多个消费倾向相加

    new_inclination = dir1

    # print(rate)
    for key in dir1.keys():
        new_inclination[key] = w[0]*int(dir1[key]) + w[1]*int(dir2[key])

    return new_inclination

def dir_average_4(dir1, dir2, dir3, dir4, w):
    # 多个消费倾向相加

    new_inclination = dir1

    # print(rate)
    for key in dir1.keys():
        new_inclination[key] = w[0]*int(dir1[key]) + w[1]*int(dir2[key]) 

    return new_inclination

def get_consume_type_wage(user):        # 返回的是属于该用户wage 的消费倾向字典                                      
                                                                           
   # 加载消费倾向与消费次数限制的json文件
    f1 = open(BASE_DIR +"/src/json_file/consume_inclination.json", 'r', encoding="UTF-8")
    consume_inclination = json.load(f1)                                                             
                                     
    wage_dir = ''
	
    # 根据消费倾向表中的概率生成每次交易的种类                                                                   
    for key in list(consume_inclination.keys()):
        if key == '-':
            wage_dir = consume_inclination[key]
            break
        # 根据工资选择消费倾向概率分布
        if user['wage'] <= int(key):
            consume_incl = consume_inclination[key].copy()

            wage_dir = consume_incl
            break

    return wage_dir

def get_consume_type_gender(user):        # 返回的是属于该用户wage 的消费倾向字典                                      
                                                                           
   # 加载消费倾向与消费次数限制的json文件
    f1 = open(BASE_DIR +"/src/json_file/consume_gender_inclination.json", 'r', encoding="UTF-8")
    consume_inclination = json.load(f1)                                                             
                                     
    gender_dir = ''
	
    # 根据消费倾向表中的概率生成每次交易的种类                                                                   
    for key in list(consume_inclination.keys()):
        # 根据工资选择消费倾向概率分布
        if user['gender'] == int(key):
            consume_incl = consume_inclination[key].copy()

            gender_dir = consume_incl
            break
    return gender_dir

def get_consume_type_loc(user):        # 返回的是属于该用户wage 的消费倾向字典                                      
                                                                           
   # 加载消费倾向与消费次数限制的json文件
    f1 = open(BASE_DIR +"/src/json_file/consume_loc_inclination.json", 'r', encoding="UTF-8")
    consume_inclination = json.load(f1)                                                             
                                     
    loc_dir = ''
	
    # 根据消费倾向表中的概率生成每次交易的种类                                                                   
    for key in list(consume_inclination.keys()):
        # 根据工资选择消费倾向概率分布
        if user['loc_id'] == int(key):
            consume_incl = consume_inclination[key].copy()

            loc_dir = consume_incl
            break
    return loc_dir

def get_consume_type_multi(user, consume_type_times):

    # 加载年龄消费倾向与年龄消费次数限制的json文件                                                                   
    f1 = open(BASE_DIR +"/src/json_file/consume_age_inclination.json", 'r', encoding="UTF-8")
    consume_age_inclination = json.load(f1)                                                      
    # print(consume_inclination)                                                             
    f2 = open(BASE_DIR +"/src/json_file/consume_age_time_limit.json", 'r', encoding="UTF-8")
    consume_time_limit = json.load(f2)                                                       
                                     
    
	# 加载该用户工资、性别、地区消费倾向字典
    wage_dir = get_consume_type_wage(user)
    gender_dir = get_consume_type_gender(user)
    loc_dir = get_consume_type_loc(user)

    average_dir = '' # 累加平均消费倾向字典（目前为年龄、收入、性别、地区）
	
    consume_type = ''
    consume_limit = ''   #  新增 消费次数限制 consume_limit

    # 加权
    w = [0.2, 0.25, 0.35, 0.2]
    # 根据消费倾向表中的概率生成每次交易的种类                                                                   
    for key in list(consume_age_inclination.keys()):                                             
        if key == '-':
			
            average_dir = dir_average_4(consume_age_inclination[key], wage_dir, gender_dir, loc_dir, w)
			
            consume_type = random_key(average_dir)                              
            break                                                                            
        # 根据年龄选择消费倾向概率分布                                                                     
        if user['age'] <= int(key):                                   
            consume_incl = consume_age_inclination[key].copy()    

            average_dir = dir_average_4(consume_incl, wage_dir, gender_dir, loc_dir, w)
			
            # 如果某种交易已经达到上限，不再考虑 
			
            for key_limit in list(consume_time_limit.keys()):      # 新增一个for循环，根据年龄消费次数限制表确定消费次数限制 consume_limit
                if key_limit == '-':                                                                       
                    consume_limit = consume_time_limit[key_limit]                          
                    break                                                                            
				# 根据年龄选择消费倾向概率分布                                                                     
                if user['age'] <= int(key_limit):
                    consume_limit = consume_time_limit[key_limit]                              
                    break  
			
            for k in consume_type_times.keys():                                              
                if consume_type_times[k] >= consume_limit[k][1]:                        
                    average_dir.pop(k)                                                      
            consume_type = random_key(average_dir)                                          
            break   
    return consume_type

def random_key(rate):
    # """随机变量的概率函数"""
    # 参数rate为dic
    # 返回概率事件的键
    start = 0
    randnum = random.randint(0, sum(list(rate.values())))
    # print(rate)
    for key in rate.keys():
        start += int(rate[key])
        if randnum <= start:
            return key

def get_consume_rank(user, c_type):
    """
    确定消费子类的函数
    :param user:
    :param c_type:
    :return:
    """
    # 加载消费倾向与消费次数限制的json文件
    # if c_type == "教育文化":
    #     return None
    f3 = open(BASE_DIR +"/src/json_file/consume_subclass_ratio.json", 'r', encoding="UTF-8")
    consume_rank = json.load(f3)

    # 加载大类的小类
    f4 = open(BASE_DIR + "/src/json_file/store_generate_ratio.json", 'r', encoding="UTF-8")
    sub_classes = json.load(f4)
    # 当前大类下的子类
    sub_class = sub_classes[c_type]
    # 商户大类相关信息
    big_class = consume_rank[c_type]

    # rank_dict = {0:'低',1:'中',2:'高'}
    # rank = 0
    # c_type_rank_dict = consume_rank[c_type]
    # for key in list(c_type_rank_dict):
    #     if key == '-':
    #         rank = random_index(c_type_rank_dict[key])
    #         break
    #     # 根据工资选择消费层次概率分布
    #     if user['wage'] <= int(key):
    #         rank = random_index(c_type_rank_dict[key])
    #         break
    # return rank_dict[rank]

    wage_list = [30000, 50000, 100000, 200000, 500000, float('inf')]
    # 工资所在区间
    index = 0
    for i in range(6):
        if user.getWage() < wage_list[i]:
            index = i
            break
    # 当前工资水平在当前大类下消费子类的概率
    sub_class_ratio = big_class[str(int(wage_list[index])) if index != 5 else "-"]

    sum_ = sum(sub_class_ratio)
    pro_list = [0 for i in range(len(sub_class_ratio))]
    for i in range(len(sub_class_ratio)):
        if i == 0:
            pro_list[i] = sub_class_ratio[i] / sum_
        else:
            pro_list[i] = pro_list[i - 1] + sub_class_ratio[i] / sum_
    r = random.random()
    # 行业小类
    industry = ''
    classes = list(sub_class.keys())
    for i in range(len(pro_list)):
        if r < pro_list[i]:
            if i > 0 and pro_list[i] != pro_list[i - 1]:
                industry = classes[i]
                break
            elif i == 0 and pro_list[i] != 0:
                industry = classes[i]
                break
    has_sub_class = ["餐饮", "医疗保健", "居住", "娱乐", "生活用品及服务"]
    if c_type in has_sub_class:
        # 加载低中高等级的概率
        f5 = open(BASE_DIR + "/src/json_file/exist_three_rank_consume_ratio.json", 'r', encoding="UTF-8")
        sub_class_rank = json.load(f5)
        sub_class_rank = sub_class_rank[industry]
        sub_class_rank = sub_class_rank[str(int(wage_list[index])) if index != 5 else "-"]
        pro_list = [0] * len(sub_class_rank)
        for i in range(len(sub_class_rank)):
            if i > 0:
                pro_list[i] = pro_list[i - 1] + sub_class_rank[i]
            else:
                pro_list[i] = sub_class_rank[i]
        r = random.randint(0, 100)
        rank_dict = {0:'低',1:'中',2:'高'}
        for i in range(len(sub_class_rank)):
            if r < pro_list[i]:
                if i > 0 and pro_list[i] != pro_list[i - 1]:
                    industry = industry + "(" + rank_dict[i] + ")"
                    break
                elif i == 0 and pro_list[i] != 0:
                    industry = industry + "(" + rank_dict[i] + ")"
                    break
    return industry


def get_consume_rank_new(user, c_type):
    """
    确定消费子类的函数
    :param user:
    :param c_type:
    :return:
    """
    # 加载消费倾向与消费次数限制的json文件
    # if c_type == "教育文化":
    #     return None
    f3 = open(BASE_DIR +"/src/json_file/consume_age_subclass_ratio.json", 'r', encoding="UTF-8")
    consume_rank = json.load(f3)

    # 加载大类的小类
    f4 = open(BASE_DIR + "/src/json_file/store_generate_ratio.json", 'r', encoding="UTF-8")
    sub_classes = json.load(f4)
    # 当前大类下的子类
    sub_class = sub_classes[c_type]
    # 商户大类相关信息
    big_class = consume_rank[c_type]

    # rank_dict = {0:'低',1:'中',2:'高'}
    # rank = 0
    # c_type_rank_dict = consume_rank[c_type]
    # for key in list(c_type_rank_dict):
    #     if key == '-':
    #         rank = random_index(c_type_rank_dict[key])
    #         break
    #     # 根据工资选择消费层次概率分布
    #     if user['wage'] <= int(key):
    #         rank = random_index(c_type_rank_dict[key])
    #         break
    # return rank_dict[rank]

    # wage_list = [30000, 50000, 100000, 200000, 500000, float('inf')]
    age_list = [15, 35, 55, float('inf')]
    # 年龄所在区间
    index = 0
    for i in range(4):
        if user.getAge() < age_list[i]:
            index = i
            break
    # 当前年龄在当前大类下消费子类的概率
    sub_class_ratio = big_class[str(int(age_list[index])) if index != 3 else "-"]

    sum_ = sum(sub_class_ratio)
    pro_list = [0 for i in range(len(sub_class_ratio))]
    for i in range(len(sub_class_ratio)):
        if sum_ == 0:
            pro_list[i] = 0
            continue

        if i == 0:
            pro_list[i] = sub_class_ratio[i] / sum_
        else:
            pro_list[i] = pro_list[i - 1] + sub_class_ratio[i] / sum_
    r = random.random()
    # 行业小类
    industry = ''
    classes = list(sub_class.keys())
    for i in range(len(pro_list)):
        if r < pro_list[i]:
            if i > 0 and pro_list[i] != pro_list[i - 1]:
                industry = classes[i]
                break
            elif i == 0 and pro_list[i] != 0:
                industry = classes[i]
                break
    has_sub_class = ["餐饮", "医疗保健", "居住", "娱乐", "生活用品及服务"]
    if c_type in has_sub_class:
        # 加载低中高等级的概率
        f5 = open(BASE_DIR + "/src/json_file/exist_three_rank_consume_ratio.json", 'r', encoding="UTF-8")
        sub_class_rank = json.load(f5)
        sub_class_rank = sub_class_rank[industry]
        sub_class_rank = sub_class_rank[str(int(age_list[index])) if index != 3 else "-"]
        pro_list = [0] * len(sub_class_rank)
        for i in range(len(sub_class_rank)):
            if i > 0:
                pro_list[i] = pro_list[i - 1] + sub_class_rank[i]
            else:
                pro_list[i] = sub_class_rank[i]
        r = random.randint(0, 100)
        rank_dict = {0:'低',1:'中',2:'高'}
        for i in range(len(sub_class_rank)):
            if r < pro_list[i]:
                if i > 0 and pro_list[i] != pro_list[i - 1]:
                    industry = industry + "(" + rank_dict[i] + ")"
                    break
                elif i == 0 and pro_list[i] != 0:
                    industry = industry + "(" + rank_dict[i] + ")"
                    break
    return industry


def random_index(rate):
    # """随机变量的概率函数"""
    # 参数rate为list
    # 返回概率事件的index,0.1.2表示低、中、高层次
    start = 0
    randnum = random.randint(0, 100)
    # print(rate)
    for index, scope in enumerate(rate):
        start += scope
        if randnum <= start:
            return index


def get_store_by_type_rank(c_type, c_rank, marchant_list):
    """
    选择消费对象
    徐昌华
    :param c_type:
    :param c_rank:
    :param marchant_list:
    :return:
    """
    marchant_candidates = []
    for marchant in marchant_list:
        marchant_info = marchant.get_store_info()
        marchant_c_type = marchant_info["industry"]
        marchant_c_rank = marchant_info["rank"]
        if marchant_c_type == c_type and marchant_c_rank==c_rank:
            marchant_candidates.append(marchant)
    marchant = random.choice(marchant_candidates)
    return marchant

def get_user_card(user,store):
    """
    根据消费的用户和商户信息，选择合适的银行卡
    赵征明
    :param user:
    :param marchant:
    :return:
    """

    card_list = user.getCard()


    return random.choice(card_list)

def get_amount(store):
    """
    赵征明
    :param store:
    :return:
    """
    consumption_range = store.getCharge_duration()
    a = random.randint(consumption_range[0],consumption_range[1])
    if a == 0:
        a += 1
    return a

def get_amount_new(user, store):
    """
    获取交易金额
    修改 get_amount函数，新增不同用户年龄的消费金额倾向表 consume_age_amount_inclination,json, 
    根据user 年龄获得倾向小额/中额/大额，和store商户区间取交集，最后在区间随机生成金额
    :param store:商户
    """

    #新增不同年龄用户消费金额倾向表
    age = user.getAge()
    jsonfile3 = BASE_DIR + '/src/json_file/consume_age_amount_inclination.json'
    consume_age_amount_inclination = read_json_file(jsonfile3)

    # json文件从小到大排序
    age_range = []
    for i in consume_age_amount_inclination:
        if i == '-':
            continue
        age_range.append(int(i))
    age_range.append(0)
    age_range.sort()
    inclination = consume_age_amount_inclination['-']
    #{"小额消费":0.50,"大额消费":0.20,"中额消费":0.30 }
    for i,range_m in enumerate(age_range):
        if i == 0:
            continue
        if age_range[i-1] <= age and age < age_range[i] :
            inclination = consume_age_amount_inclination[str(range_m)]
            break
    
    while True :
        #根据年龄随机获得小额/中额/大额倾向
        np.random.seed(0)
        #p = np.array(inclination.values())
        #amount_type = np.random.choice(inclination.keys(), p = p.ravel())
        amount_type = random_key(inclination)
        #小额消费
        #获取商户金额区间
        amount_range = store.getCharge_duration()
        #[30,100]

        if amount_type == "小额消费":
            amount_range[-1] = min(100, amount_range[-1])
        elif amount_type == "中额消费":
            amount_range[0] = max(100, amount_range[0])
            amount_range[-1] = min(1000, amount_range[-1])
        else :
            amount_range[0] = max(1000, amount_range[0])

        if amount_range[0] >= amount_range[-1] :
            continue
        else :
            break
    
    ratio = round(random.random(),2)
    a = random.randint(amount_range[0],amount_range[1])
    if a == 0:
        a += 1
    a += ratio
    return a

def get_consume_times(user):
    f1 = open(BASE_DIR +"/src/json_file/consume_age_inclination.json", 'r', encoding="UTF-8")
    consume_age_inclination = json.load(f1)
    f2 = open(BASE_DIR +"/src/json_file/consume_age_time_limit.json", 'r', encoding="UTF-8")
    consume_age_time_limit = json.load(f2)

    age = user.getAge()
    # print(age)
    # print(consume_age_inclination)
    # inclination = consume_age_inclination['-']

    # json文件中的key从小到大排序
    consume_range = []
    for i in consume_age_inclination:
        if i == '-':
            continue
        consume_range.append(int(i))
    consume_range.append(0)
    consume_range.sort()
    inclination = consume_age_inclination['-']
    for i,range_m in enumerate(consume_range):
        if i == 0:
            continue
        if consume_range[i-1] <= age and age < consume_range[i] :
            inclination = consume_age_inclination[str(range_m)]
            break

    # 新增按年龄分布的消费次数限制
    consume_time = []
    for i in consume_age_time_limit:
        if i == '-':
            continue
        consume_time.append(int(i))
    consume_time.append(0)
    consume_time.sort()
    consume_time_limit = consume_age_time_limit['-']
    for i,range_m in enumerate(consume_time):
        if i == 0:
            continue
        if consume_time[i-1] <= age and age < consume_time[i] :
            consume_time_limit = consume_age_time_limit[str(range_m)]
            break

    times_max = 0
    for c_type in inclination:
        if c_type in consume_time_limit:
            times_max += inclination[c_type] * consume_time_limit[c_type][-1] * 0.02
    randnum = random.randint(0, int(times_max)+i)
    return randnum

def get_consume_times_multi(user):
    f1 = open(BASE_DIR +"/src/json_file/consume_age_inclination.json", 'r', encoding="UTF-8")
    consume_age_inclination = json.load(f1)
    f2 = open(BASE_DIR +"/src/json_file/consume_age_time_limit.json", 'r', encoding="UTF-8")
    consume_age_time_limit = json.load(f2)

    age = user['age']
    # print(age)
    # print(consume_age_inclination)
    # inclination = consume_age_inclination['-']

    # 加载该用户工资、性别、地区消费倾向字典
    wage_dir = get_consume_type_wage(user)
    gender_dir = get_consume_type_gender(user)
    loc_dir = get_consume_type_loc(user)
	
    average_dir = '' # 累加平均消费倾向字典（目前为年龄、收入、性别、地区）

    # 加权
    w = [0.2, 0.25, 0.35, 0.2]
    # 根据消费倾向表中的概率生成每次交易的种类                                                                   
    for key in list(consume_age_inclination.keys()):                                             
        if key == '-':
            average_dir = dir_average_4(consume_age_inclination[key], wage_dir, gender_dir, loc_dir, w)
			           
            break                                                                            
        # 根据年龄选择消费倾向概率分布                                                                     
        if user['age'] <= int(key):                                   
            consume_incl = consume_age_inclination[key].copy()    

            average_dir = dir_average_4(consume_incl, wage_dir, gender_dir, loc_dir, w)

    # 新增按年龄分布的消费次数限制
    consume_time = []
    for i in consume_age_time_limit:
        if i == '-':
            continue
        consume_time.append(int(i))
    consume_time.append(0)
    consume_time.sort()
    consume_time_limit = consume_age_time_limit['-']
    for i,range_m in enumerate(consume_time):
        if i == 0:
            continue
        if consume_time[i-1] <= age and age < consume_time[i] :
            consume_time_limit = consume_age_time_limit[str(range_m)]
            break

    times_max = 0
    for c_type in average_dir:
        if c_type in consume_time_limit:
            times_max += average_dir[c_type] * consume_time_limit[c_type][-1] * 0.02
    randnum = random.randint(0, int(times_max)+i)
    return randnum