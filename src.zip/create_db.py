# import pymysql as mysql
import os

# 基础路径 BASE_DIR = ././YTSystem/
import pymysql

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

db_connection = pymysql.connect(
    host='10.176.25.111',
    user='root',
    password='123456',
    # db='sf_web_001',
    port=3306,
    charset='utf8')


# creating database_cursor to perform SQL operation
db_cursor = db_connection.cursor()
# executing cursor with execute method and pass SQL query
db_cursor.execute("CREATE DATABASE sf_web_001")
# get list of all databases
db_cursor.execute("SHOW DATABASES")
#print all databases
for db in db_cursor:
	print(db)